# sing-box-mod

chenzai666 定制维护的 sing-box 一键安装与管理脚本。

## 定制内容

### 1. 支持手动指定服务器 IP（`-i / --ip` 参数）

安装时可通过 `-i` 参数手动指定服务器 IP，避免自动探测失败：

```bash
bash install.sh -i 1.2.3.4
bash install.sh -i 2001:db8::1       # IPv6
bash install.sh -i 1.2.3.4 -v v1.11.0 -p http://127.0.0.1:7890
```

### 2. 持久化自定义 IP / 域名（`sing-box ip set/clear`）

安装后修改配置时，IP 会被自动探测覆盖。定制版支持将 IP（或域名）持久化到配置文件：

```bash
sing-box ip set 1.2.3.4          # 设置固定 IP
sing-box ip set my.ddns.com      # 设置域名（DDNS，动态 IP 机器适用）
sing-box ip clear                 # 恢复自动探测
sing-box ip                        # 查看当前 IP / 域名
```

- 输入值会做校验，既不是 IP 也不是域名时报错
- 填域名时，节点地址与分享链接都使用该域名，**DDNS 更新 IP 后无需改动配置**
- 域名解析校验（`host-test`）会自动把该域名解析成真实 IP 再比对；解析不出来时跳过校验，不阻断安装

### 3. Reality Short ID 随机生成

- 使用 `sing-box generate rand 4 --hex` 生成 4 字节 8 位十六进制 Short ID（与主流客户端兼容性最佳）
- 配置文件中不再使用空字符串 `[""]`，改为随机值
- 分享链接 URL 中包含正确的 `sid=` 参数
- 查看配置 (`sing-box info`) 时会显示 Short ID

### 4. 菜单支持"更改 Short ID"

在"更改配置"菜单中新增选项（选项 13），支持随时修改 Short ID：

```bash
sing-box change                    # 选择 13. 更改 Short ID
sing-box change 13                 # 交互式输入新值
sing-box change 13 auto            # 自动随机生成新值
sing-box change 13 abc12345        # 指定具体值
```

### 5. 支持 anytls-reality

协议菜单新增 `anytls-reality`，序号为 21。可用命令别名直接添加：

```bash
sing-box add anytls-reality [port] [password] [sni]
```

生成的分享链接格式为 `anytls://...?security=reality&...`，并包含 `pbk` 与 `sid` 参数。

### 6. anytls 自签场景对齐甬哥 argosbx 风格

无域名时使用自签证书的 anytls，默认注入伪装 SNI 并双参数跳过证书验证，导入客户端即开即用：

- 分享链接：`anytls://密码@IP:端口?sni=www.bing.com&insecure=1&allowInsecure=1#...`
- 服务端 TLS 配置自动补 `server_name: www.bing.com` + `insecure: true`
- `insecure` 兼容 sing-box 系客户端，`allowInsecure` 兼容 v2rayN 系，无需手动开启跳过证书验证
- Reality 伪装握手端口可用 `SB_HANDSHAKE_PORT` 环境变量自定义（默认 443）

### 7. 环境变量一键安装（批量部署）

`install.sh` 默认安装 reality；可通过环境变量一条命令批量安装任意协议组合：

```bash
# 默认安装 reality（向后兼容）
bash <(curl -Ls https://raw.githubusercontent.com/chenzai666/sing-box-mod/main/install.sh)

# 额外安装 anytls
SB_ANYTLS=1 bash <(curl -Ls .../install.sh)

# 额外安装 anytls-reality
SB_ANYTLS_REALITY=1 bash <(curl -Ls .../install.sh)

# 自定义协议列表 + 伪装端口（空格分隔）
SB_PROTOCOLS="reality anytls-reality" SB_HANDSHAKE_PORT=8443 bash <(curl -Ls .../install.sh)
```

批量安装时末尾统一重启服务，不再每个协议重启一次。

### 8. anytls 真域名证书复用（`/etc/ssl` 优先，无则 ACME）

带域名安装 anytls 时，优先复用服务器已有的真域名证书，避免重复 ACME 申请：

- 检测 `/etc/ssl/cert.crt` + `/etc/ssl/private.key`，存在则直接引用（`certificate_path` + `key_path`）
- 不存在则自动走 ACME 申请（sing-box ≥ 1.14 用 `certificate_provider`，旧版用 `acme`）
- 证书路径可用 `SB_CERT_FILE` / `SB_KEY_FILE` 环境变量覆盖（例如 certd 等工具签发后放置的证书）

```bash
# 方式一：交互式添加（菜单选择证书方式）
sing-box add anytls [port] [password]
#   未指定域名时会弹出菜单：
#     1. 自签证书 (SNI www.bing.com, 跳过验证)
#     2. 域名证书 (复用 /etc/ssl 或 ACME 申请) → 输入域名
sing-box add anytls [port] [password] example.com   # 直接传域名证书，跳过询问

# 方式二：环境变量一键安装（优先复用 /etc/ssl 证书，无则 ACME 申请）
SB_ANYTLS_DOMAIN=example.com bash <(curl -Ls .../install.sh)

# 自定义证书路径（可选）
SB_ANYTLS_DOMAIN=example.com SB_CERT_FILE=/etc/ssl/cert.crt SB_KEY_FILE=/etc/ssl/private.key \
  bash <(curl -Ls .../install.sh)
```

`sing-box info` / `change` 流程可正确识别三种证书模式（ACME 域名 / 外部证书 / 自签），展示与修改不受影响。批量安装（`SB_ANYTLS`）默认自签，不会弹出询问。

### 9. 脚本自更新（`sing-box self-update`）

一键将脚本更新到 GitHub main 分支最新版，不依赖 Release tag（与代码仓库版本脱节时也能正确更新）：

```bash
sing-box self-update     # 或简写: sing-box su
sing-box update sh       # 等价
sing-box update          # 无参数: 先更新脚本, 再更新核心(一步到位)
```

> 注意：`sing-box update`（无参数）会**先检查脚本更新、再更新核心**；若只更新了核心而脚本仍是旧版（例如早期版本只更新核心），新功能可能不生效，请使用上面的命令更新脚本。

更新逻辑：

- 从 `https://raw.githubusercontent.com/chenzai666/sing-box-mod/main/code.tar.gz` 拉取最新包
- 对比包内 `sing-box.sh` 的内置版本号（`is_sh_ver`）与当前版本，一致则提示已是最新
- 有新版本时**先备份**当前脚本到 `$is_sh_dir/backup-<旧版本>`，再覆盖安装，失败可随时回滚
- 主菜单「更新 → 更新脚本」与 `sing-box U` / `update.sh` 同样走此逻辑

**旧版脚本引导升级**（无 `self-update` 命令时）：

```bash
bash <(curl -Ls https://raw.githubusercontent.com/chenzai666/sing-box-mod/main/install.sh) update-sh
```

> 适用场景：服务器脚本过旧（`sb self-update` 报"无法识别"、`sb update` 只更新核心不更新脚本）。`update-sh` 仅覆盖 `$is_sh_dir` 脚本文件（自动备份旧版到 `backup-<旧版本>`），**不动 sing-box 核心与 `/etc/sing-box/conf` 配置**，升级后 `sb add anytls` 即可看到证书方式选择菜单。

### 10. IP 探测多源化（`get_ip`）

原版获取服务器 IP 只依赖 Cloudflare `cdn-cgi/trace` **单源**，且请求无超时：Cloudflare 不通就直接报错退出，网络异常时还可能长时间卡住。定制版改为多源轮询：

| 顺序 | 数据源 | 解析方式 |
|---|---|---|
| 1 | `one.one.one.one/cdn-cgi/trace` | 取 `ip=` 字段 |
| 2 | `api.ipify.org` | 直接取返回体 |
| 3 | `ifconfig.me` | 直接取返回体 |
| 4 | `icanhazip.com` | 直接取返回体 |

- 先试 IPv4（`-4`）后试 IPv6（`-6`），每个请求 `-T 8` 超时、`-t 1` 不重试
- 返回值做 IP 格式校验（IPv4 / IPv6），非 IP 结果丢弃并继续下一源
- 全部失败才报错退出；已设置自定义 IP / 域名时直接短路，不发起探测

## 安装

```bash
wget -qO- https://raw.githubusercontent.com/chenzai666/sing-box-mod/main/install.sh | bash
```

或下载后本地执行：

```bash
git clone https://github.com/chenzai666/sing-box-mod.git
cd sing-box-mod
bash install.sh
```

## 与原版的主要差异

| 功能 | 上游原版 | 本定制版 |
|------|------------|---------|
| 安装时指定 IP | 不支持 | `-i <IP>` |
| IP 持久化 | 无，每次探测覆盖 | `sing-box ip set`（支持 IP 或域名） |
| DDNS 域名地址 | 无 | `sing-box ip set my.ddns.com`，校验时自动解析比对 |
| IP 探测 | Cloudflare 单源、无超时 | 4 源轮询 + 每源 8s 超时，先 IPv4 后 IPv6 |
| Reality short_id | 硬编码空字符串 `[""]` | 随机 4 字节 hex |
| 更改 short_id | 无 | `sing-box change 13` |
| anytls-reality | 无 | `sing-box add anytls-reality`，菜单序号 21 |
| anytls 自签 SNI | 无 | 默认 `www.bing.com` 伪装 |
| anytls 跳过证书验证 | 仅 `allowInsecure=1` | `insecure=1&allowInsecure=1` 双参数 |
| 批量安装 | 无 | `SB_PROTOCOLS` / `SB_ANYTLS` / `SB_ANYTLS_REALITY` |
| Reality 伪装端口 | 固定 443 | `SB_HANDSHAKE_PORT` 可配 |
| anytls 真域名证书 | 仅 ACME 申请 | 优先复用 `/etc/ssl` 已有证书（`SB_ANYTLS_DOMAIN`） |
| anytls 证书方式选择 | 无，只能命令行传域名 | 交互式菜单选择 自签 / 域名证书 |
| 脚本自更新 | 依赖 Release tag 判断版本 | `su / self-update` 直接对比 main 分支内置版本，先备份后更新 |

## 原版特性

继承上游脚本的主要功能，包括 VLESS Reality、anytls-reality、Shadowsocks、Trojan、VMess 等协议的一键配置和管理。

## License

MIT
