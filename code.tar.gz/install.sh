#!/bin/bash

author=chenzai666
# github=https://github.com/chenzai666/sing-box

# bash fonts colors
red='\e[31m'
yellow='\e[33m'
gray='\e[90m'
green='\e[92m'
blue='\e[94m'
magenta='\e[95m'
cyan='\e[96m'
none='\e[0m'
_red() { echo -e ${red}$@${none}; }
_blue() { echo -e ${blue}$@${none}; }
_cyan() { echo -e ${cyan}$@${none}; }
_green() { echo -e ${green}$@${none}; }
_yellow() { echo -e ${yellow}$@${none}; }
_magenta() { echo -e ${magenta}$@${none}; }
_red_bg() { echo -e "\e[41m$@${none}"; }

is_err=$(_red_bg 错误!)
is_warn=$(_red_bg 警告!)

err() {
    echo -e "\n$is_err $@\n" && exit 1
}

warn() {
    echo -e "\n$is_warn $@\n"
}

# root
[[ $EUID != 0 ]] && err "当前非 ${yellow}ROOT用户.${none}"

# apt-get, yum, zypper or apk
cmd=$(type -P apt-get || type -P yum || type -P zypper || type -P apk)
[[ ! $cmd ]] && err "此脚本仅支持 ${yellow}(Ubuntu or Debian or CentOS or SUSE or Alpine)${none}."

# systemd or openrc
is_systemd=$(type -P systemctl)
is_openrc=$(type -P rc-service)
[[ ! $is_systemd && ! $is_openrc && ! $cmd =~ apk ]] && {
    err "此系统缺少 ${yellow}(systemctl 或 rc-service)${none}, 请安装 systemd 或确认 OpenRC 已启用."
}

# wget installed or none
is_wget=$(type -P wget)

# x64
case $(uname -m) in
amd64 | x86_64)
    is_arch=amd64
    ;;
*aarch64* | *armv8*)
    is_arch=arm64
    ;;
*)
    err "此脚本仅支持 64 位系统..."
    ;;
esac

is_core=sing-box
is_core_name=sing-box
is_core_dir=/etc/$is_core
is_core_bin=$is_core_dir/bin/$is_core
is_core_repo=SagerNet/$is_core
is_conf_dir=$is_core_dir/conf
is_log_dir=/var/log/$is_core
is_sh_bin=/usr/local/bin/$is_core
is_sh_dir=$is_core_dir/sh
is_sh_repo=chenzai666/sing-box-mod
is_pkg="wget curl ca-certificates tar bash"
# Alpine: install OpenRC and common utilities up front to avoid silent waits.
[[ $cmd =~ apk ]] && is_pkg="$is_pkg openrc gcompat jq coreutils"
is_config_json=$is_core_dir/config.json
# local cache
is_core_cached=
# GitHub proxy fallback
gh_proxy="https://gh-proxy.com/"
tmp_var_lists=(
    tmpcore
    tmpsh
    tmpjq
    is_core_ok
    is_sh_ok
    is_jq_ok
    is_pkg_ok
)

# tmp dir
tmpdir=$(mktemp -u)
[[ ! $tmpdir ]] && {
    tmpdir=/tmp/tmp-$RANDOM
}

# set up var
for i in ${tmp_var_lists[*]}; do
    export $i=$tmpdir/$i
done

# load bash script.
load() {
    . $is_sh_dir/src/$1
}

# check local cache
check_local_cache() {
    # check if sing-box binary already exists
    if [[ -f $is_core_bin ]] && [[ -x $is_core_bin ]]; then
        local cached_ver=$($is_core_bin version 2>/dev/null | head -n1 | grep -E -o 'v[0-9.]+' | head -1)
        if [[ $cached_ver ]]; then
            is_core_cached=$cached_ver
            msg warn "检测到本地 sing-box: ${yellow}${is_core_cached}${none}"
        fi
    fi
}

# wget add --no-check-certificate, with timeout
_wget() {
    [[ $proxy ]] && export https_proxy=$proxy
    wget --no-check-certificate --timeout=60 --tries=2 $*
}

# curl with timeout
_curl() {
    [[ $proxy ]] && export https_proxy=$proxy
    curl -fsSL --max-time 60 --retry 2 $*
}

_curl_fast() {
    [[ $proxy ]] && export https_proxy=$proxy
    curl -fsSL --connect-timeout 5 --max-time 8 --retry 1 $*
}

# print a mesage
msg() {
    case $1 in
    warn)
        local color=$yellow
        ;;
    err)
        local color=$red
        ;;
    ok)
        local color=$green
        ;;
    esac

    echo -e "${color}$(date +'%T')${none}) ${2}"
}

# show help msg
show_help() {
    echo -e "Usage: $0 [-f xxx | -i xxx | -l | -p xxx | -v xxx | -h]"
    echo -e "  -f, --core-file <path>          自定义 $is_core_name 文件路径, e.g., -f /root/$is_core-linux-amd64.tar.gz"
    echo -e "  -i, --ip <addr>                 自定义服务器 IP 或域名, 跳过自动探测"
    echo -e "  -l, --local-install             本地获取安装脚本, 使用当前目录"
    echo -e "  -p, --proxy <addr>              使用代理下载, e.g., -p http://127.0.0.1:7890"
    echo -e "  -v, --core-version <ver>        自定义 $is_core_name 版本, e.g., -v v1.8.13"
    echo -e "  -h, --help                      显示此帮助界面\n"

    exit 0
}

# install dependent pkg
install_pkg() {
    cmd_not_found=
    for i in $*; do
        [[ ! $(type -P $i) ]] && cmd_not_found="$cmd_not_found,$i"
    done
    if [[ $cmd_not_found ]]; then
        pkg=$(echo $cmd_not_found | sed 's/,/ /g')
        msg warn "安装依赖包 >${pkg}"
        if [[ $cmd =~ apk ]]; then
            apk update
            apk add --no-cache $pkg
        else
            $cmd install -y $pkg &>/dev/null
            if [[ $? != 0 ]]; then
                [[ $cmd =~ yum ]] && yum install epel-release -y &>/dev/null
                if [[ $cmd =~ zypper ]]; then
                    $cmd --non-interactive refresh &>/dev/null
                else
                    $cmd update -y &>/dev/null
                fi
                $cmd install -y $pkg &>/dev/null
            fi
        fi
        [[ $? == 0 ]] && >$is_pkg_ok
    else
        >$is_pkg_ok
    fi
}

# download file
download() {
    fallback_link=
    case $1 in
    core)
        name=$is_core_name
        tmpfile=$tmpcore
        is_ok=$is_core_ok
        # check if local cached version matches the target version
        if [[ $is_core_cached ]] && [[ $is_core_ver == $is_core_cached ]]; then
            msg warn "本地缓存版本 ${yellow}${is_core_cached}${none} 已是最新, 跳过下载"
            return 0
        fi
        # Alpine works best with its native package. It avoids GitHub release
        # redirects and glibc compatibility edge cases on musl systems.
        if [[ $cmd =~ apk && ! $is_core_ver ]]; then
            msg warn "Alpine 系统优先使用 edge/community 安装 ${name}..."
            if apk add --no-cache --repository=https://dl-cdn.alpinelinux.org/alpine/edge/community $is_core; then
                local _apk_bin=$(type -P $is_core)
                if [[ $_apk_bin ]]; then
                    local _apk_ver=$($_apk_bin version 2>/dev/null | head -n1 | grep -E -o 'v[0-9.]+' | head -1)
                    [[ $_apk_ver ]] && is_core_ver=$_apk_ver
                    mkdir -p $tmpdir/apk_pkg/sing-box-apk
                    cp -f $_apk_bin $tmpdir/apk_pkg/sing-box-apk/$is_core
                    tar czf $is_ok -C $tmpdir/apk_pkg sing-box-apk 2>/dev/null
                    [[ -f $is_ok ]] && return 0
                fi
            fi
            msg warn "Alpine 原生安装失败, 继续尝试 GitHub 下载..."
        fi
        # get latest version from GitHub API
        [[ ! $is_core_ver ]] && {
            is_core_ver=$(_curl -s "https://api.github.com/repos/${is_core_repo}/releases/latest?v=$RANDOM" | grep tag_name | grep -E -o 'v([0-9.]+)')
            [[ ! $is_core_ver ]] && is_core_ver=$(_curl -s "${gh_proxy}https://api.github.com/repos/${is_core_repo}/releases/latest?v=$RANDOM" | grep tag_name | grep -E -o 'v([0-9.]+)')
        }
        [[ $is_core_ver ]] && link="https://github.com/${is_core_repo}/releases/download/${is_core_ver}/${is_core}-${is_core_ver:1}-linux-${is_arch}.tar.gz"
        # 1) Direct download with curl -L (follows GitHub 302 redirect)
        if [[ $link ]]; then
            msg warn "下载 ${name} ${is_core_ver}..."
            if _curl -L $link -o $tmpfile; then
                mv -f $tmpfile $is_ok
                return 0
            fi
            # 2) Fallback via gh-proxy
            msg warn "直连失败, 尝试代理下载..."
            if _curl -L "${gh_proxy}${link}" -o $tmpfile; then
                mv -f $tmpfile $is_ok
                return 0
            fi
        fi
        # 3) Last resort: sing-box official installer
        msg warn "GitHub 下载失败, 尝试 sing-box 官方安装脚本..."
        if bash <(_curl https://sing-box.app/install.sh) 2>/dev/null; then
            local _official_bin=$(type -P sing-box)
            if [[ $_official_bin ]]; then
                msg ok "官方脚本安装成功"
                local _official_ver=$($_official_bin version 2>/dev/null | head -n1 | grep -E -o 'v[0-9.]+' | head -1)
                [[ $_official_ver ]] && is_core_ver=$_official_ver
                # package into tar.gz for uniform handling
                mkdir -p $tmpdir/official_pkg/sing-box-official
                cp -f $_official_bin $tmpdir/official_pkg/sing-box-official/sing-box
                tar czf $is_ok -C $tmpdir/official_pkg sing-box-official 2>/dev/null
                if [[ -f $is_ok ]]; then
                    return 0
                fi
            fi
        fi
        msg err "下载 ${name} 失败, 所有渠道均不可用"
        return 1
        ;;
    sh)
        link=https://raw.githubusercontent.com/${is_sh_repo}/main/code.tar.gz
        fallback_link=https://cdn.jsdelivr.net/gh/${is_sh_repo}@main/code.tar.gz
        name="$is_core_name 脚本"
        tmpfile=$tmpsh
        is_ok=$is_sh_ok
        ;;
    jq)
        link=https://github.com/jqlang/jq/releases/download/jq-1.7.1/jq-linux-$is_arch
        name="jq"
        tmpfile=$tmpjq
        is_ok=$is_jq_ok
        ;;
    esac

    [[ $link ]] && {
        msg warn "下载 ${name} > ${link}"
        if _wget -q -c $link -O $tmpfile; then
            mv -f $tmpfile $is_ok
        else
            rm -f $tmpfile
            if [[ $fallback_link ]]; then
                msg warn "直连失败, 尝试备用下载 > ${fallback_link}"
                if _wget -q -c "$fallback_link" -O $tmpfile; then
                    mv -f $tmpfile $is_ok
                    return 0
                fi
                rm -f $tmpfile
            fi
            # fallback to gh-proxy
            msg warn "直连失败, 尝试代理下载 > ${gh_proxy}${link}"
            if _wget -q -c "${gh_proxy}${link}" -O $tmpfile; then
                mv -f $tmpfile $is_ok
            fi
        fi
    }
}

# get server ip
get_ip() {
    [[ $ip ]] && return 0
    local _ip
    for url in \
        https://one.one.one.one/cdn-cgi/trace \
        https://api.ipify.org \
        https://ifconfig.me \
        https://icanhazip.com; do
        if [[ $url == *cdn-cgi/trace ]]; then
            _ip=$(_curl_fast "$url" 2>/dev/null | awk -F= '/^ip=/{print $2; exit}' | tr -d '[:space:]')
        else
            _ip=$(_curl_fast "$url" 2>/dev/null | tr -d '[:space:]')
        fi
        if [[ $_ip =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ || $_ip =~ : ]]; then
            ip=$_ip
            export ip
            return 0
        fi
    done
    return 1
}

# check background tasks status
check_status() {
    # dependent pkg install fail
    [[ ! -f $is_pkg_ok ]] && {
        msg err "安装依赖包失败"
        if [[ $cmd =~ apk ]]; then
            msg err "请尝试手动安装依赖包: apk update; apk add $is_pkg"
        else
            msg err "请尝试手动安装依赖包: $cmd update -y; $cmd install -y $is_pkg"
        fi
        is_fail=1
    }

    # download file status
    if [[ $is_wget ]]; then
        # check if using local cache (core already exists)
        if [[ $is_core_cached ]] && [[ -f $is_core_bin ]]; then
            >$is_core_ok
            msg ok "使用本地缓存 ${is_core_name} ${is_core_cached}"
        fi
        [[ ! -f $is_core_ok ]] && {
            msg err "下载 ${is_core_name} 失败"
            is_fail=1
        }
        [[ ! -f $is_sh_ok ]] && {
            msg err "下载 ${is_core_name} 脚本失败"
            is_fail=1
        }
        [[ ! -f $is_jq_ok ]] && {
            msg err "下载 jq 失败"
            is_fail=1
        }
    else
        [[ ! $is_fail ]] && {
            is_wget=1
            [[ ! $is_core_file ]] && download core &
            [[ ! $local_install ]] && download sh &
            [[ $jq_not_found ]] && download jq &
            get_ip
            wait
            check_status
        }
    fi

    # found fail status, remove tmp dir and exit.
    [[ $is_fail ]] && {
        exit_and_del_tmpdir
    }
}

# parameters check
pass_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
        -f | --core-file)
            [[ -z $2 ]] && {
                err "($1) 缺少必需参数, 正确使用示例: [$1 /root/$is_core-linux-amd64.tar.gz]"
            } || [[ ! -f $2 ]] && {
                err "($2) 不是一个常规的文件."
            }
            is_core_file=$2
            shift 2
            ;;
        -i | --ip)
            [[ -z $2 ]] && {
                err "($1) 缺少必需参数, 正确使用示例: [$1 1.2.3.4]"
            }
            ip=$2
            custom_ip=$2
            export ip
            shift 2
            ;;
        -l | --local-install)
            [[ ! -f ${PWD}/src/core.sh || ! -f ${PWD}/$is_core.sh ]] && {
                err "当前目录 (${PWD}) 非完整的脚本目录."
            }
            local_install=1
            shift 1
            ;;
        -p | --proxy)
            [[ -z $2 ]] && {
                err "($1) 缺少必需参数, 正确使用示例: [$1 http://127.0.0.1:7890 or -p socks5://127.0.0.1:7890]"
            }
            proxy=$2
            shift 2
            ;;
        -v | --core-version)
            [[ -z $2 ]] && {
                err "($1) 缺少必需参数, 正确使用示例: [$1 v1.8.13]"
            }
            is_core_ver=v${2//v/}
            shift 2
            ;;
        -h | --help)
            show_help
            ;;
        *)
            echo -e "\n${is_err} ($@) 为未知参数...\n"
            show_help
            ;;
        esac
    done
    [[ $is_core_ver && $is_core_file ]] && {
        err "无法同时自定义 ${is_core_name} 版本和 ${is_core_name} 文件."
    }
}

# exit and remove tmpdir
exit_and_del_tmpdir() {
    rm -rf $tmpdir
    [[ ! $1 ]] && {
        msg err "哦豁.."
        msg err "安装过程出现错误..."
        echo -e "反馈问题) https://github.com/${is_sh_repo}/issues"
        echo
        exit 1
    }
    exit
}

# main
main() {

    # check old version
    [[ -f $is_sh_bin && -d $is_core_dir/bin && -d $is_sh_dir && -d $is_conf_dir ]] && {
        err "检测到脚本已安装, 如需重装请使用${green} ${is_core} reinstall ${none}命令."
    }

    # check parameters
    [[ $# -gt 0 ]] && pass_args $@

    # show welcome msg
    clear
    echo
    echo "........... $is_core_name script by $author .........."
    echo

    # start installing...
    msg warn "开始安装..."
    [[ $is_core_ver ]] && msg warn "${is_core_name} 版本: ${yellow}$is_core_ver${none}"
    [[ $proxy ]] && msg warn "使用代理: ${yellow}$proxy${none}"

    # check local cache
    check_local_cache
    # create tmpdir
    mkdir -p $tmpdir
    # if is_core_file, copy file
    [[ $is_core_file ]] && {
        cp -f $is_core_file $is_core_ok
        msg warn "${yellow}${is_core_name} 文件使用 > $is_core_file${none}"
    }
    # local dir install sh script
    [[ $local_install ]] && {
        >$is_sh_ok
        msg warn "${yellow}本地获取安装脚本 > $PWD ${none}"
    }

    if [[ $is_systemd ]]; then
        timedatectl set-ntp true &>/dev/null
        [[ $? != 0 ]] && {
            is_ntp_on=1
        }
    fi

    # install dependent pkg
    install_pkg $is_pkg

    # refresh commands after dependency installation.
    is_wget=$(type -P wget)
    is_systemd=$(type -P systemctl)
    is_openrc=$(type -P rc-service)
    [[ ! $is_systemd && ! $is_openrc ]] && {
        msg err "此系统缺少 ${yellow}(systemctl 或 rc-service)${none}, 请安装 systemd 或确认 OpenRC 已启用."
        exit_and_del_tmpdir
    }

    [[ $custom_ip ]] && {
        mkdir -p $is_core_dir
        echo "$custom_ip" >$is_core_dir/custom_ip
        msg warn "使用自定义服务器 IP: ${yellow}$custom_ip${none}"
    }

    # jq
    if [[ $(type -P jq) ]]; then
        >$is_jq_ok
    else
        jq_not_found=1
    fi
    # if wget installed. download core, sh, jq, get ip
    [[ $is_wget ]] && {
        [[ ! $is_core_file ]] && download core &
        [[ ! $local_install ]] && download sh &
        [[ $jq_not_found ]] && download jq &
        get_ip
    }

    # waiting for background tasks is done
    wait

    # check background tasks status
    check_status

    # test $is_core_file
    if [[ $is_core_file ]]; then
        mkdir -p $tmpdir/testzip
        tar zxf $is_core_ok --strip-components 1 -C $tmpdir/testzip &>/dev/null
        [[ $? != 0 ]] && {
            msg err "${is_core_name} 文件无法通过测试."
            exit_and_del_tmpdir
        }
        [[ ! -f $tmpdir/testzip/$is_core ]] && {
            msg err "${is_core_name} 文件无法通过测试."
            exit_and_del_tmpdir
        }
    fi

    # get server ip.
    [[ ! $ip ]] && {
        msg err "获取服务器 IP 失败."
        exit_and_del_tmpdir
    }

    # create sh dir...
    mkdir -p $is_sh_dir

    # copy sh file or unzip sh zip file.
    if [[ $local_install ]]; then
        cp -rf $PWD/* $is_sh_dir
    else
        tar zxf $is_sh_ok -C $is_sh_dir
    fi

    # create core bin dir
    mkdir -p $is_core_dir/bin
    # copy core file or unzip core zip file
    if [[ $is_core_file ]]; then
        cp -rf $tmpdir/testzip/* $is_core_dir/bin
    elif [[ $is_core_cached ]] && [[ -f $is_core_bin ]]; then
        # use local cached binary
        msg ok "使用本地缓存 ${is_core_name} ${is_core_cached}"
    else
        tar zxf $is_core_ok --strip-components 1 -C $is_core_dir/bin
    fi

    # add alias
    echo "alias sb=$is_sh_bin" >>/root/.bashrc
    echo "alias $is_core=$is_sh_bin" >>/root/.bashrc

    # core command
    ln -sf $is_sh_dir/$is_core.sh $is_sh_bin
    ln -sf $is_sh_dir/$is_core.sh ${is_sh_bin/$is_core/sb}

    # jq
    [[ $jq_not_found ]] && mv -f $is_jq_ok /usr/bin/jq

    # chmod
    chmod +x $is_core_bin $is_sh_bin /usr/bin/jq ${is_sh_bin/$is_core/sb}

    # create log dir
    mkdir -p $is_log_dir

    # show a tips msg
    msg ok "生成配置文件..."

    # create service
    load systemd.sh
    is_new_install=1
    install_service $is_core &>/dev/null

    # create condf dir
    mkdir -p $is_conf_dir

    # init is_core_ver & self-signed tls cert
    # (原版 init.sh 中完成, install 流程不走 init.sh, 装 anytls 前必须补齐)
    is_core_ver=$($is_core_bin version | head -n1 | cut -d " " -f3)
    is_tls_cer=$is_core_dir/bin/tls.cer
    is_tls_key=$is_core_dir/bin/tls.key
    [[ ! -f $is_tls_cer || ! -f $is_tls_key ]] && {
        is_tls_tmp=${is_tls_key/key/tmp}
        $is_core_bin generate tls-keypair tls -m 456 >$is_tls_tmp
        awk '/BEGIN PRIVATE KEY/,/END PRIVATE KEY/' $is_tls_tmp >$is_tls_key
        awk '/BEGIN CERTIFICATE/,/END CERTIFICATE/' $is_tls_tmp >$is_tls_cer
        rm $is_tls_tmp
    }

    load core.sh
    # 默认安装 reality; 可通过环境变量额外安装 anytls / anytls-reality
    # 用法: SB_ANYTLS_REALITY=1 bash <(curl -Ls ...)
    #       或 SB_PROTOCOLS="reality anytls-reality" 自定义协议列表 (空格分隔)
    #       或 SB_HANDSHAKE_PORT=8443 自定义 Reality 伪装端口
    #       或 SB_ANYTLS_DOMAIN=example.com 安装真域名证书 anytls
    #         (优先复用 /etc/ssl/cert.crt + /etc/ssl/private.key, 无则 ACME)
    is_batch_install=1
    for p in ${SB_PROTOCOLS:-reality}; do
        add $p auto
    done
    [[ $SB_ANYTLS ]] && add anytls auto
    [[ $SB_ANYTLS_REALITY ]] && add anytls-reality auto
    # 真域名证书 anytls: 优先复用 /etc/ssl/cert.crt + /etc/ssl/private.key (存在时),
    # 不存在则 ACME 申请。路径可用 SB_CERT_FILE / SB_KEY_FILE 覆盖。
    [[ $SB_ANYTLS_DOMAIN ]] && add anytls auto auto $SB_ANYTLS_DOMAIN
    is_batch_install=
    # unified restart after batch install
    manage restart &
    # wait for background tasks (e.g., OpenRC service start)
    wait
    # remove tmp dir and exit.
    exit_and_del_tmpdir ok
}

# start.
main $@
